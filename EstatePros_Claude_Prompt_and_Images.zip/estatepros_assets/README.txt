ESTATEPROS CARPET CLEANING | STARTER IMAGE PACK & CLAUDE BUILD PROMPT

Inside:
CLAUDE_BUILD_PROMPT.md - detailed copy-and-paste prompt for Claude
images/ - four individual photorealistic concept images, each as WEBP and JPG

All four images were generated as conceptual advertising imagery, not documented EstatePros staff, property, equipment or actual work. They may be used as illustrative website imagery subject to your review. Do not present them as real customer before/after evidence. Replace with approved business photographs when available.

For Claude: upload this extracted folder or pass along the files under images/ with the prompt. Ensure actual business details are supplied before publishing.

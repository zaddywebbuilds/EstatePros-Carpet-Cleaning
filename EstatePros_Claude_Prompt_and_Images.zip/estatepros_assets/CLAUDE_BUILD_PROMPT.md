# CLAUDE MASTER BUILD PROMPT: ESTATEPROS CARPET CLEANING

You are a senior creative director, award-winning web designer, conversion-rate optimization specialist, local SEO strategist, and expert front-end developer. Build a complete, distinctive, fully responsive production-quality website for **EstatePros Carpet Cleaning**, serving **Calgary, Alberta, Canada**.

## MANDATORY REFERENCES
- Visual quality, composition, sophistication, art direction and motion inspiration: https://zaddyjohn-cyber.github.io/Oasismassagestudio/
- Business listing: https://www.google.com/maps/place/EstatePros+Carpet+Cleaning/@51.0860872,-114.0440112,10z/data=!3m1!4b1!4m6!3m5!1s0x20aa5244cb8ef709:0xf98cf8b9469edc5a!8m2!3d51.0860872!4d-114.0440112!16s%2Fg%2F11ntp89kds
- Attached visual assets are under `/images/` and MUST be used. Their filenames and purposes are specified below.

## IMPORTANT FACTUAL INTEGRITY
The business name and Calgary context are known. The exact phone number, address, staff names, service menu, years of operation, insurance/certifications, equipment, cleaning methods, satisfaction guarantees, service regions, review scores, review counts, customer quotes, prices, offers, and business hours have NOT been independently verified. Do not make them up. Use editable placeholders in a central business config for unverified details. The service suggestions below are potential site architecture, not confirmed offerings: retain only services verified by owner. Never claim generated imagery is documentary photography of EstatePros, actual staff, its van, actual projects, or proof of cleaning results. Generated imagery is conceptual and should eventually be replaced with authorized company imagery where suitable. Do not use invented Google testimonials, star scores, badges, certification marks, or false before/after claims. Only use real, authorized proof.

## GOAL & STYLE
Create an extraordinary premium local service brand experience that feels like high-end architecture / interior-design photography meets crisp utility-first home services. Inspired by the reference's sophisticated pacing, large type, editorial imagery, airy layout, floating layered cards, polished depth, soft light and tasteful interaction, but DO NOT copy its page, assets, texts or color scheme. No generic cleaning-service template. The visual message: 'Your spaces deserve exceptional care.'

Colors (CSS variables): deep teal #102C33, dark ink #162328, warm ivory #F7F5F0, mist #DCECE9, muted champagne #B5A185, clean white #FFFFFF, support grey #687576. Teal is the hero base; ivory dominates content; champagne is a rare accent for premium calls to action. Strong contrast and accessible hover/focus states. Avoid neon, hard blue gradients, excessive gold, or overdecorated glassmorphism.

Fonts: editorial heading e.g. Manrope / Plus Jakarta Sans / DM Sans, contrasting restrained serif accent such as Cormorant Garamond ONLY in selected hero words, UI type Inter. Responsive type via clamp(). Never use tiny body text.

Photography: all photography MUST feel absolutely photorealistic, architectural, natural, not synthetic/CGI. Favor soft Calgary daytime window light, physically accurate equipment, believable textile fibers, authentic neutral interiors, proper scale and ergonomics. No giant floating spray bottles, fake foam, surreal sparkling floors, distorted hands or AI artifacts. Supplied images are conceptual photography, not actual documented company work.

3D feel: accomplish with carefully applied CSS perspective, layered cards, soft long shadows, parallax limited to transforms, hover tilt <= 4 degrees, animated light gradients and tasteful image reveal. Add progressive enhancement; site must look excellent with animations disabled. No needless heavy WebGL libraries.

## SITE STRUCTURE
Build production-ready MULTI-PAGE website or route-based React/Vite project with:
1. Home (`/`)
2. Services overview (`/services`)
3. Dedicated service pages only for OWNER-CONFIRMED services, with draft structures for `/services/carpet-cleaning`, `/services/upholstery-cleaning`, `/services/area-rug-cleaning`, `/services/stain-odour-treatment`, `/services/commercial-carpet-cleaning`; unverified pages must not be published or indexed until approved.
4. About (`/about`)
5. Gallery (`/gallery`) with honest conceptual image captions; never market AI concept photos as past customer work.
6. Reviews (`/reviews`) with embed or verified sourced actual reviews only; if none available, show CTA to verified Google profile rather than invented content.
7. Contact / Request a Quote (`/contact`)
8. Privacy Policy / accessibility / page not found.

## HOME PAGE EXACT ART DIRECTION AND CONTENT
A. Top microbar: 'Serving Calgary, Alberta' on left; business phone ONLY when verified, otherwise show simple 'Request a Quote' link. Sticky minimal navigation with EstatePros text/logotype; desktop nav: Home, Services, Our Approach, Gallery, Reviews, Contact; mobile animated accessible drawer. Top CTA 'Get a Free Quote' is permitted only if the owner confirms quotes are free, otherwise 'Request a Quote'.
B. Hero, desktop ~90svh: full-bleed photo of premium living room / authentic carpet care with cinematic deep-teal scrim. Editorial headline, large and broken into meaningful lines: 'Beautiful spaces. / Brilliantly cared for.' Eyebrow 'ESTATEPROS · CALGARY'. Supporting copy: 'Thoughtful carpet care for the spaces you live and work in. Tell us what needs attention and we'll help you take the next step.' Two CTAs: 'Request a Quote' and 'Explore Services'. Floating refined lower-corner mini-card labeled 'Carpet care, considered' and another with small close-up. Crisp photo, no huge white slabs obstructing the room. Reveal on load (350–650ms). Mobile hero foreground legibility is paramount.
C. Trust ribbon: 3-4 *non-credential* benefits phrased carefully, e.g. 'Easy quote requests', 'Made for lived-in spaces', 'Residential enquiries', 'Calgary enquiries'. Do not state 24/7, fully insured, pet-safe, certified, or guaranteed unless substantiated.
D. Editorial About / Difference section: asymmetrical split layout with an image, vertical label, large oversized text: 'Good care changes the way a room feels.' Describe listening to customer's needs and preparing an appropriate cleaning approach, without unsubstantiated technical claims. Small floating appointment preview card.
E. Services: photorealistic editorial image cards, featured carpet cleaning plus OWNER-VERIFIED services. Hover depth and controlled diagonal image crop. Each card has actual service copy, 'Learn more' link, and CTA 'Get a quote'. If owner cannot confirm secondary services, show only Carpet Cleaning and a general 'Ask about your space' enquiry panel. Never publish services because they are common in the industry.
F. Transformation storytelling: separate image pairs ONLY if they are real EstatePros-supplied matched before/after photos. Until then, replace with an 'Our work, up close' photography gallery of illustrative images with 'Concept photography' alt/caption; no before/after slider or numerical cleaning claim.
G. 3-step booking journey: 'Tell us about the space', 'Get details confirmed', 'Schedule your service'. Quote request is an enquiry, not confirmed availability. Floating layered journey cards with scroll motion.
H. Service-area feature: 'Carpet Cleaning in Calgary' with a tasteful city/architecture collage and an embedded Google Maps link; no fabricated local neighborhood coverage. Add verified communities only when confirmed by owner.
I. Testimonials: only authentic sourced reviews with permissions/attribution; otherwise display 'Read customer feedback on Google' linking the supplied Google Maps listing, not invented quotes or rating count.
J. FAQs: questions for booking, preparing for a clean, drying, stain treatment, quote details, moving furniture, pets, residential/commercial work. Answers should be qualified until owner confirms policies/equipment. Do NOT guarantee stain removal or drying duration.
K. Closing CTA: warm living room photo with dark overlay, copy 'Ready to feel the difference in your space?' and 'Tell us about your carpets and we'll help you plan the next step.' prominent 'Request a Quote'.
L. Footer: brand, Calgary, navigation, verified contacts only, hours only when supplied, privacy, copyright year dynamically set. No fabricated address or social profile.

## IMAGE USE
Use supplied optimized images by filename:
- `/images/estatepros-hero-living-room.webp`: main cinematic hero / beautiful space.
- `/images/estatepros-technician-extraction.webp`: service process card / featured carpet cleaning.
- `/images/estatepros-upholstery-detail.webp`: upholstery concept tile ONLY IF service confirmed; otherwise use under 'care in the details'.
- `/images/estatepros-carpet-wand-detail.webp`: equipment/texture close-up, process section.
All images are generated editorial concepts. Do not mention they are pictures of company staff or jobs. Use `loading="lazy"` below fold, explicit dimensions or `aspect-ratio`, responsive `srcset` if supplied, consistent object-position, alt text that describes visible objects rather than claims about the business. Provide a prompt-friendly image registry so additional real pictures can be swapped in later. Do not use competitor photos or copyrighted photos scraped online.

## CONTACT / LEAD FORM THAT ACTUALLY WORKS
The entire website must be functional, not just a visual mockup. Include accessible validation and states. Fields: full name, email, Canadian phone (optional or required according to owner), property type, requested service (owner-verified only), approximate number of rooms/area, preferred date (request only, no false slots), Calgary address/neighborhood as optional, message, consent checkbox. Client-side validation PLUS server-side verification. Connect via a configurable provider such as Formspree, Resend through secure backend/serverless endpoint, or Netlify Forms depending on deployment. Do not store API keys in browser source. If not yet configured, show explicit DEMO MODE instructions and do not pretend submissions have been delivered. Avoid displaying success until endpoint returns success. Add bot protection/honeypot, rate limit and spam filtering. Include tap-to-call and email buttons once real contact details are supplied.

## DEVELOPMENT STACK AND CODE QUALITY
Preferred: React + Vite + TypeScript + Tailwind CSS, Lucide React, Framer Motion selectively; use React Router if multi-route. If user supplies a simple static GitHub Pages requirement, prefer semantic HTML/CSS/vanilla JS or static React with correctly configured base path. Clean component architecture: Navbar, Hero, TrustBar, ServiceGrid, EditorialSection, Gallery, Process, FAQs, QuoteForm, Footer. Central `/src/config/business.ts` typed business data, content editable without chasing JSX. Deployable to GitHub Pages with base path and SPA fallback support or static export as appropriate.

Use no broken links, dead buttons, pretend functional calendars, embedded fake WhatsApp chats, fake business reviews, invented actual staff identities or invented phone numbers. Honor real form interactions. Menus, tabs, gallery interactions, accordion keyboard interactions, and quote form are operational. Motion must be efficient, scroll animations via IntersectionObserver where feasible, and respects `prefers-reduced-motion`. Meet WCAG 2.2 AA basics: readable contrast, focus visible, label association, `aria-expanded`, accessible escape-to-close mobile nav, semantic headings, skip link, keyboard access, descriptive image alt. Mobile 360px upwards with no horizontal overflow and thumb-friendly CTAs. Images lazy-load below fold; avoid layout shift. Aim Lighthouse >= 90 for performance, accessibility, best practices and SEO under realistic production conditions.

## LOCAL SEO AND METADATA
Research keywords carefully, without keyword stuffing: 'carpet cleaning Calgary', 'professional carpet cleaning Calgary', 'Calgary carpet cleaners'. Use unique natural titles and meta descriptions per approved page, canonical URL after domain selected, Open Graph/Twitter meta tags and optimized OG image, robots.txt, sitemap.xml, breadcrumbs on services. JSON-LD for appropriate LocalBusiness/CarpetCleaning business type only with verified NAP, business URL, service list, actual hours and coordinates. Do not emit made-up aggregateRating/review markup or fake credentials. Create city-focused copy that feels human and trustworthy, not automated search text. If exact service area is unknown, do not make city-wide guarantee. Map the given GBP profile with a normal link rather than assuming it's a street-address storefront.

## DELIVERABLES / DEFINITION OF DONE
1. Complete runnable project and file tree, no placeholders except legitimately unverified business facts/integrations clearly identified.
2. All pages, compelling copy, responsive design, real interactions, image references, and SEO.
3. `README.md`: setup, dev/build commands, deploy to GitHub Pages or chosen host, replace company data, connect form/email, add real imagery, verify owner facts.
4. `OWNER_APPROVAL_CHECKLIST.md`: phone, email, hours, service list, exact Calgary service area, business details, pricing, certifications/insurance if claimed, real reviews, photos, confirmation of quote policies, domain, notification destination, privacy terms.
5. Screenshot/readability QA at mobile 375px, tablet 768px and desktop 1440px; test all links, form errors/success, open/close, touch interaction, reduced-motion preference.
6. Final output must be ready to deploy, not a high-level plan, pseudo-code or partial homepage.

Go ahead and IMPLEMENT the entire website. Prioritize visual quality and functional completion, then give a concise project structure and launch instructions.
